package com.controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DAO.DAO;



@WebServlet(name = "ProductInsertion", urlPatterns = "/ProductInsertion")
public class ProductInsertionController extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
		response.sendRedirect("Register.jsp");
	}
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		boolean hasError = false;
		String errors = "";
		String successful="";

		String paramProdName = request.getParameter("name");
		String paramProdQuantity = request.getParameter("quantity");
		String paramProdCategory = request.getParameter("category");
		
		int paramProdPrice =0;
	
		if(!isWhiteSpace(request.getParameter("price"))) {
			paramProdPrice=Integer.parseInt(request.getParameter("price"));
		}
		if (paramProdName == null || paramProdName.trim().length() == 0) {
			errors = "Please fill all the fields";
			hasError = true;
		}
		if (paramProdQuantity == null || paramProdQuantity.trim().length() == 0) {
			errors = "Please fill all the fields";
			hasError = true;
		}
		if (paramProdCategory == null || paramProdCategory.trim().length() == 0) {
			errors = "Please fill all the fields";
			hasError = true;
		}
		if (paramProdPrice ==0) {
			errors = "Please fill all the fields";
			hasError = true;
		}
		
		if(hasError) {
			request.setAttribute("errors", errors);
			RequestDispatcher rd= getServletContext().getRequestDispatcher("/Register.jsp");
			rd.forward(request, response);
		}
		else {
				DAO dao=new DAO();
				dao.putProduts(paramProdName, paramProdQuantity, paramProdCategory, paramProdPrice);
				 successful="Saved Successfully";
				request.setAttribute("successful", successful);
				RequestDispatcher rd= getServletContext().getRequestDispatcher("/Register.jsp");
				rd.forward(request, response);
				
		}
		

	}
	
	private boolean isWhiteSpace(String s) {
		return s.chars().allMatch(Character::isWhitespace);
	}
}
