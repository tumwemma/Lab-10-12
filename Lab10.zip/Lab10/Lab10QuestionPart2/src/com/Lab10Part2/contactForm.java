package com.Lab10Part2;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class contactForm
 */
@WebServlet(description = "contactForm", urlPatterns = { "/contactForm" })

public class contactForm extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private  int numberOfVisit;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public contactForm() {
        super();
        // TODO Auto-generated constructor stub
    }
  
    public void init() {
    	numberOfVisit=0;	
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int globalCount=(int)request.getServletContext().getAttribute("globalCount");
		String name= "";String gender= "";String category= "";String message= "";
		String errorName="";
		String errorGender="";
		String errorMessage="";
		String errorCategory="";
		numberOfVisit++;
		System.out.println("this is gender from contacts"+request.getParameter("gender"));
		String paramName="";
		String paramMessage="";
		Map<String,String> errorsMap=(HashMap<String,String>)request.getAttribute("errorsMap");
		if(errorsMap!=null&&errorsMap.get("name")!=null) {
			 errorName="<div style=\"color: red;\">"+errorsMap.get("name")+"</div>";}
		if(errorsMap!=null&&errorsMap.get("gender")!=null) {
			 errorGender= "<div style=\"color: red;\">"+errorsMap.get("gender")+"</div>";}
		if(errorsMap!=null&&errorsMap.get("message")!=null) {
			 errorMessage= "<div style=\"color: red;\">"+errorsMap.get("message")+"</div>";}
		if(errorsMap!=null&&errorsMap.get("category")!=null) {
			 errorCategory= "<div style=\"color: red;\">"+errorsMap.get("category")+"</div>";
			}
		
		if(request.getParameter("name")!=null) {
			
			paramName=request.getParameter("name");}
		
			if(request.getParameter("message")!=null) {
			
			paramMessage=request.getParameter("message");}
		
		if(request.getAttribute("name")!=null)
			name = "<div style=\"color: red;\">"+(String) request.getAttribute("name")+"</div>";		
		if(request.getAttribute("gender")!=null)
			gender = "<div style=\"color: red;\">"+(String) request.getAttribute("gender")+"</div>";
		if(request.getAttribute("category")!=null)
			category = "<div style=\"color: red;\">"+(String) request.getAttribute("category")+"</div>";
		if(request.getAttribute("message")!=null)
			message = "<div style=\"color: red;\">"+(String) request.getAttribute("message")+"</div>";
		System.out.println("Gender is " + gender + " Category is "+ category);
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		pw.append("<!DOCTYPE html><html lang=\"en\"><head>"
				+ "<meta charset=\"UTF-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"><meta http-equiv=\"X-UA-Compatible\" content=\"ie=edge\"> "
				+ "<title>Document</title> "
				+ " <link href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css\"\r\n" + 
				"    rel=\"stylesheet\" integrity=\"sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T\"\r\n" + 
				"    crossorigin=\"anonymous\">"
				+ "</head>");
		pw.append("<body><header class=\"box header\">\r\n" + 
				"                <nav class=\"navbar navbar-expand-lg navbar-dark bg-primary\">\r\n" + 
				"                  <a style=\"padding-right: 2em;\" class=\"navbar-brand\" href=\"#\">CS472-WA ::: Lab 10</a>\r\n" + 
				"              \r\n" + 
				"                  <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarColor01\" aria-controls=\"navbarColor01\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">\r\n" + 
				"                    <span class=\"navbar-toggler-icon\"></span>\r\n" + 
				"                  </button>\r\n" + 
				"                  <a class=\"navbar-brand\" href=\"#\"> Home</a>\r\n" + 
				"                  <a class=\"navbar-brand\" href=\"#\"> About US</a>\r\n" + 
				"                  <a class=\"navbar-brand\" href=\"contactForm\"> Contact us</a>\r\n" + 
				"                  <div class=\"collapse navbar-collapse\" id=\"navbarColor01\">\r\n" + 
				"                    <ul class=\"navbar-nav mr-auto\">\r\n" + 
				"                      <!-- Menu -->\r\n" + 
				"                    </ul>\r\n" + 
				"                    <form class=\"form-inline my-2 my-lg-0\">\r\n" + 
				"                      <a style=\"color: #ffffff; margin-right: 0;\" class=\"nav-link\" href=\"#\">\r\n" + 
				"                            <input class=\"form-control mr-sm-2\" type=\"search\" placeholder=\"Search\" aria-label=\"Search\">\r\n" + 
				"                      </a>\r\n" + 
				"                      <a href=\"#\" class=\"btn btn-secondary\">Search</a>\r\n" + 
				"                    </form>\r\n" + 
				"                  </div>\r\n" + 
				"                </nav>\r\n" + 
				"            </header> <div class=\"container\">\r\n" + 
				"                    <section class=\"form-register  \">\r\n" + 
				"                      <form  action= \"ValidateForm1\" method= \"Post\"id=\"frm-register\" class=\"needs-validation\" novalidate style=\"margin-bottom: 2em;\">\r\n" + 
				"                \r\n" + 
				"                        <!-- Account No -->\r\n" + 
				"                       \r\n" + 
				"                          <label for=\"txtAccountNo\">Customer contact Form</label>\r\n" + 
				"                          \r\n" + 
				"                        \r\n" + 
				"                \r\n" + 
				"                        <!-- Customer Name -->\r\n" + 
				"                        <div class=\"form-group\">\r\n" + 
				"                          <label for=\"txtCustomerName\">* Name:</label>"
				+ "\r\n" + 
				"                          <input type=\"text\" name=\"name\" class=\"form-control\" id=\"txtCustomerName\"  placeholder=\"\" value="+paramName+">"
				+ "\r\n" + 
				"                          <div>"+errorName+"</div>\r\n" + 
				"                        </div>"
				+ "\r\n" + 
				"\r\n" + 
				"                        \r\n" + 
				"                            <!-- Radion buttons-->\r\n" + 
				"                            <div class=\"form-group\">\r\n" + 
				"                            <label for=\"txtCustomerName\">*Gender:</label>\r\n" + 
				"                            </div>\r\n" + 
				"							<div class=\"form-check-inline\" >\r\n" + 
				"                                    <label class=\"form-check-label\">\r\n" + 
				"                                      <input type=\"radio\" class=\"form-check-input\" value=\"Male\" name=\"gender\">Male\r\n" + 
				"                                    </label>\r\n" + 
				"                                  </div>\r\n" + 
				"                                  <div class=\"form-check-inline\">\r\n" + 
				"                                    <label class=\"form-check-label\">\r\n" + 
				"                                      <input type=\"radio\" class=\"form-check-input\" value=\"Female\" name=\"gender\">Female\r\n" + 
				"                                    </label>\r\n" + 
				"                                  </div>"+errorGender+"\r\n" + 
				"                                  \r\n" + 
				"                               \r\n" + 
				"                \r\n" + 
				"                        <!-- Customer Type -->\r\n" + 
				"                        <div class=\"form-group\">\r\n" + 
				"                          <label for=\"selAccountType\">*Category:</label>\r\n" + 
				"                          <select class=\"form-control\" id=\"selAccountType\" name=\"category\">\r\n" + 
				"                            <option value=\"Select category\">Select category</option>\r\n" + 
				"                            <option value=\"Inquiry\">Inquiry</option>\r\n" + 
				"                            <option value=\"Feedback\">Feedback</option>\r\n" + 
				"                            <option value=\"Complaint\">Complaint</option>\r\n" + 
				"                          </select>"+errorCategory+"\r\n" + 
				"                        </div><!-- Message body -->\r\n" + 
				"                        <div class=\"form-group\">\r\n" + 
				"                          <label class=\" control-label\" for=\"message\">*Your message:</label>\r\n" + 
				"                          <div class=\"\">\r\n" + 
				"                            <textarea class=\"form-control\" id=\"message\" name=\"message\"  placeholder=\"\" rows=\"5\">"+paramMessage+"</textarea>"+errorMessage+"\r\n" + 
				"                          </div>\r\n" + 
				"                        </div>\r\n" + 
				"                \r\n" + 
				"                        <button type=\"submit\" id=\"btnSubmit\" class=\"btn btn-primary\">Submit</button>\r\n" + 
				"                \r\n" + 
				"                      </form><div<label >Hit counter for this page:"+this.numberOfVisit+"</label></div>"
				+ 						"<div style=\"margin-left: 130px;\"><label >Hit counter for this entire WebAPP: "+globalCount+"</label></div>\r\n" + 
				"                    </section>\r\n" + 
				"                \r\n" + 
				"                  </div>\r\n" + 
				"</body>\r\n" + 
				"</html>");
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            doPost(request, response);
	}

}
