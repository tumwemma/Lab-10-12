package com.Lab10Part2;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ValidateForm1
 */
@WebServlet(description = "ValidateForm1", urlPatterns = { "/ValidateForm1" })

public class ValidateForm1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ValidateForm1() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	RequestDispatcher rd= getServletContext().getRequestDispatcher("/contactForm");
		rd.forward(request, response);
    }
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name= request.getParameter("name");
		String gender= request.getParameter("gender");
		String category= request.getParameter("category");
		String message= request.getParameter("message");
		
		Map<String,String> errorsMap=new HashMap<>();
		boolean hasError = false;
		if(name==null||name.trim().length()==0) {
			errorsMap.put("name", "Missing a name");
			//request.setAttribute("name", "missing a name");
			hasError = true;
		}
		if(gender==null) {
			errorsMap.put("gender", "Missing a gender");
		//	request.setAttribute("gender", "missing a gender");
			hasError = true;
		}
		//System.out.println("Category in validate form is" + category);
		if(category.equals("Select category")) {
			//request.setAttribute("category", "missing a category");
			errorsMap.put("category", "Missing a category");
			hasError = true;
		}
		if(message==null||message.trim().length()==0) {
			//request.setAttribute("message", "No message");
			errorsMap.put("message", "No message");
			hasError = true;
		}
		
		if(hasError){
			request.setAttribute("errorsMap",errorsMap );
			RequestDispatcher rd= getServletContext().getRequestDispatcher("/contactForm");
			rd.forward(request, response);
//			PrintWriter out= response.getWriter();
//			out.println("<div style=\"font-size:20px; color: red;\">you must fill in all fields</div>");
//			rd.include(request, response);
		} else {
			//request.setAttribute("name", name);
//			request.setAttribute("gender", gender);
//			request.setAttribute("category", category);
//			request.setAttribute("message", message);
			response.sendRedirect("ThankYou?name="+name+"&&gender="+gender+"&&category="+category+"&&message="+message);
			//RequestDispatcher rd= getServletContext().getRequestDispatcher("/ThankYou");
			//rd.forward(request, response);
		}
		
		
	}

}
