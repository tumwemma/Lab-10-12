//how to display the value of gender
//doget and dopost





package com.Lab10Part2;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ThankYou
 */
@WebServlet("/ThankYou")
public class ThankYou extends HttpServlet {
	private static final long serialVersionUID = 1L;
       private static int numberOfVisit;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ThankYou() {
        super();
        // TODO Auto-generated constructor stub
    }

      public void init() {
    	numberOfVisit=0;	
    }
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		numberOfVisit++;
		String time= LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, dd MMMM yyyy"));
		int globalCount= (int)request.getServletContext().getAttribute("globalCount");
		String responseName =(String)request.getParameter("name");
		String responseGender = (String)request.getParameter("gender");
		String responseCategory =(String) request.getParameter("category");
		String responseMessage = (String)request.getParameter("message");
		System.out.println("this is gender from thank you"+responseGender);
		response.setContentType("text/html");
		PrintWriter write = response.getWriter();
		
		write.append("<!DOCTYPE html>\r\n" + 
				"<html lang=\"en\">\r\n" + 
				"\r\n" + 
				"<head>\r\n" + 
				"    <meta charset=\"UTF-8\">\r\n" + 
				"    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n" + 
				"    <meta http-equiv=\"X-UA-Compatible\" content=\"ie=edge\">\r\n" + 
				"    <title>Document</title>\r\n" + 
				"\r\n" + 
				"    <link href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css\" rel=\"stylesheet\"\r\n" + 
				"        integrity=\" sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T\\\" crossorigin=\"anonymous\">\r\n" + 
				"    <style>\r\n" + 
				"        .section {\r\n" + 
				"            background-color: lightgray;\r\n" + 
				"            margin-top: 5%;\r\n" + 
				"            padding-left: 1px;\r\n" + 
				"            padding-right: 1px;\r\n" + 
				"            padding-bottom: 0px;\r\n" + 
				"        }\r\n" + 
				"\r\n" + 
				"        .reduceSize {\r\n" + 
				"            font-size: 14px;\r\n" + 
				"        }\r\n" + 
				"\r\n" + 
				"        .gridstyle {\r\n" + 
				"            display: grid;\r\n" + 
				"            grid-template-rows: 20% 70%;\r\n" + 
				"            grid-row-gap: 22px;\r\n" + 
				"        }\r\n" + 
				"\r\n" + 
				"        .gridstyle H3 {\r\n" + 
				"            background-color: lightgray;\r\n" + 
				"        }\r\n" + 
				"\r\n" + 
				"        .gridstyle div:nth-child(2) {\r\n" + 
				"            display: grid;\r\n" + 
				"            grid-auto-columns: 100%;\r\n" + 
				"            background-color: white;\r\n" + 
				"        }\r\n" + 
				"        .globalCount{\r\n" + 
				"            margin-right: 30%;\r\n" + 
				"            float: left;\r\n" + 
				"        }\r\n" + 
				"        .numberOfVisit{\r\n" + 
				"            margin-left: 110px;\r\n" + 
				"        }\r\n" + 
				"    </style>\r\n" + 
				"</head>\r\n" + 
				"\r\n" + 
				"<body>\r\n" + 
				"    <header class=\"box header\">\r\n" + 
				"        <nav class=\"navbar navbar-expand-lg navbar-dark bg-primary\">\r\n" + 
				"            <a style=\"padding-right: 2em;\" class=\"navbar-brand\" href=\"#\">CS472-WA ::: Lab 10</a>\r\n" + 
				"            <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarColor01\"\r\n" + 
				"                aria-controls=\" navbarColor01\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">\r\n" + 
				"                <span class=\"navbar-toggler-icon\"></span>\r\n" + 
				"            </button>\r\n" + 
				"            <a class=\"navbar-brand\" href=\"#\"> Home</a>\r\n" + 
				"            <a class=\"navbar-brand\" href=\"#\"> About US</a>\r\n" + 
				"            <a class=\"navbar-brand\" href=\"contactForm\"> Contact us</a>\r\n" + 
				"            <div class=\"collapse navbar-collapse\" id=\"navbarColor01\">\r\n" + 
				"                \r\n" + 
				"               \r\n" + 
				"            </div>\r\n" + 
				"        </nav>\r\n" + 
				"    </header>\r\n" + 
				"   <div style=\"float:right; margin-right:50%;\"><span >"+time+"</span></div> <div class=\"container section gridstyle\">\r\n" + 
				"\r\n" + 
				"        <h3 class=\"\">Thank you ! your message has been received as follow</h3>\r\n" + 
				"\r\n" + 
				"        <div class=\"container\">\r\n" + 
				"            <div>\r\n" + 
				"                <label>Name: "+responseName+"</label>\r\n" + 
				"            </div>\r\n" + 
				"            <div>\r\n" + 
				"                <label>Gender: "+responseGender+"</label>\r\n" + 
				"            </div>\r\n" + 
				"            <div>\r\n" + 
				"                <label>Category: "+responseCategory+"</label>\r\n" + 
				"\r\n" + 
				"            </div>\r\n" + 
				"            <div>\r\n" + 
				"                <label>Message: "+responseMessage+"</label>\r\n" + 
				"            </div>\r\n" + 
				"\r\n" + 
				"            <div>\r\n" + 
				"                <p>Please feel free to<a href=\" contactForm\">Contact Us</a> again </p>\r\n" + 
				"            </div>\r\n" + 
				"\r\n" + 
				"        </div>\r\n" + 
				"    </div>\r\n" + 
				"    <div class=\"numberOfVisit\"><label>Hit counter for this page: "+numberOfVisit+"</label>\r\n" + 
				"    <div class=\"globalCount\"><label >Hit counter for this entire WebAPP: "+globalCount+"</label></div>\r\n" + 
				"</div>\r\n" + 
				"</body>\r\n" + 
				"\r\n" + 
				"</html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
//	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		// TODO Auto-generated method stub
//		doGet(request, response);
//	}

}
