package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ContactPageValidatorServlet
 */
@WebServlet("/ContactPageValidatorServlet")
public class ContactPageValidatorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ContactPageValidatorServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	 private boolean isWhiteSpace(String s){
	        return s.chars().allMatch(Character::isWhitespace);
	    }
	 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<String> list = new ArrayList<String>();
		String name = request.getParameter("name");
        String gender = request.getParameter("gender");
        String category = request.getParameter("category");
        String message = request.getParameter("message");
        
        HttpSession session= request.getSession();
    	
        
        if (name == null || name.equals("") || isWhiteSpace(name)) {
            list.add("Fill in the Name");
        }
        if (message == null || message.equals("") || isWhiteSpace(message)) {
            list.add("Add missing message");
        }
        if (gender == null || gender.equals("")||isWhiteSpace(gender)) {
            list.add("Select your gender");
        }
        if (category == null || category.equals("")||isWhiteSpace(category)) {
            list.add("Select Category");
        }
        
        session.setAttribute("name", name);
        session.setAttribute("gender", gender);
        session.setAttribute("category", category);
        session.setAttribute("message", message);
        session.setAttribute("errors", list);
        if (list.size() != 0) {
        	response.sendRedirect("contactUs.jsp");
        }
        else {
        	String counter = ((Integer)request.getAttribute("TotalCounter")).toString();
        	
        	response.sendRedirect("thankYou.jsp");
        }
	}

}
