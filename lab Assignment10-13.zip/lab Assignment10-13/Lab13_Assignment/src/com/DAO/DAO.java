package com.DAO;

import java.sql.*;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.List;

import com.models.Product;

public class DAO {
	private static final String MY_SQL_DRIVER = "com.mysql.cj.jdbc.Driver";
	private static final String USER_NAME = "root";
	private static final String PASS_WORD = "Emma@123";
	private static final String URL = "jdbc:mysql://localhost:3306/my_bd";

	

	public boolean check(String username, String password) {
		String query = "select * from users where username=? and pass=?";

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(URL, USER_NAME, PASS_WORD);
			PreparedStatement statement = con.prepareStatement(query);
			statement.setString(1, username);
			statement.setString(2, password);
			ResultSet result = statement.executeQuery();
			System.out.print(result);
			if (result.next()) {
				System.out.print(" found");
				return true;

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		// System.out.print("not found");

		return false;
	}

	// products

	public List<Product> getProduts() {
		String query = "select * from products ";
		List<Product> productsList = new ArrayList<>();

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(URL, USER_NAME, PASS_WORD);
			PreparedStatement statement = con.prepareStatement(query);

			ResultSet result = statement.executeQuery();

			if (result != null) {
				while (result.next()) {
					int ID = result.getInt("prodID");
					String name = result.getString("prodName");
					String quantity = result.getString("prodQuantity");
					String category = result.getString("prodCategory");
					double price = result.getDouble("prodPrice");
					Product product = new Product();
					product.setProductID(ID);
					product.setProductName(name);
					product.setProductQuantity(quantity);
					product.setProductCategory(category);
					product.setProductPrice(price);
					productsList.add(product);

				}

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		// System.out.print("not found");
		return productsList;

	}

	public void putProduts(String inputName, String inputQuantity, String inputCategory, double inputPrice) {
		String query = "insert into products (prodName,prodQuantity,prodCategory,prodPrice)values(?,?,?,?) ";

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(URL, USER_NAME, PASS_WORD);
			PreparedStatement statement = con.prepareStatement(query);
			statement.setString(1, inputName);
			statement.setString(2, inputQuantity);
			statement.setString(3, inputCategory);
			statement.setDouble(4, inputPrice);

			int result = statement.executeUpdate();
			System.out.println(result);

		} catch (Exception e) {
			e.printStackTrace();
		}
		// System.out.print("not found");

	}
	
	public List<Product> search(String prodname) {
		String query = "select * from products where prodName=? ";
		
		List<Product> productsList = new ArrayList<>();

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(URL, USER_NAME, PASS_WORD);
			PreparedStatement statement = con.prepareStatement(query);
			statement.setString(1, prodname);

			ResultSet result = statement.executeQuery();
			if (result != null) {
				while (result.next()) {
					int ID = result.getInt("prodID");
					String name = result.getString("prodName");
					String quantity = result.getString("prodQuantity");
					String category = result.getString("prodCategory");
					double price = result.getDouble("prodPrice");
					Product product = new Product();
					product.setProductID(ID);
					product.setProductName(name);
					product.setProductQuantity(quantity);
					product.setProductCategory(category);
					product.setProductPrice(price);
					productsList.add(product);

				}
		

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		// System.out.print("not found");
		return productsList;

		}

}
